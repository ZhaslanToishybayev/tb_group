#!/bin/bash

# 🔒 TB Group Base Stack - Security Audit Script
# Version: 1.0
# Purpose: Comprehensive security scanning for the repository
# Usage: ./scripts/security-audit.sh [--verbose] [--fix]

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Flags
VERBOSE=false
AUTO_FIX=false
ERRORS=0
WARNINGS=0

# Parse arguments
while [[ $# -gt 0 ]]; do
  case $1 in
    --verbose|-v)
      VERBOSE=true
      shift
      ;;
    --fix|-f)
      AUTO_FIX=true
      shift
      ;;
    --help|-h)
      echo "Usage: $0 [--verbose] [--fix]"
      echo ""
      echo "Options:"
      echo "  --verbose, -v    Show detailed output"
      echo "  --fix, -f        Automatically fix issues where possible"
      echo "  --help, -h       Show this help message"
      exit 0
      ;;
    *)
      echo "Unknown option: $1"
      exit 1
      ;;
  esac
done

# Helper functions
log_info() {
  echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
  echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
  echo -e "${YELLOW}[⚠]${NC} $1"
  ((WARNINGS++))
}

log_error() {
  echo -e "${RED}[✗]${NC} $1"
  ((ERRORS++))
}

log_verbose() {
  if [ "$VERBOSE" = true ]; then
    echo -e "${BLUE}[VERBOSE]${NC} $1"
  fi
}

# Check if running from project root
if [ ! -f "package.json" ] || [ ! -d ".git" ]; then
  log_error "This script must be run from the project root directory"
  exit 1
fi

log_info "🔒 Starting Security Audit for TB Group Base Stack"
echo ""

# ==========================================
# 1. Check for exposed API keys and credentials
# ==========================================
log_info "Checking for exposed API keys and credentials..."

# Patterns to search for (high-entropy strings that look like keys)
API_KEY_PATTERNS=(
  "sk-[a-zA-Z0-9]{48}"           # OpenAI API keys
  "xox[baprs]-[a-zA-Z0-9-]{10,48}" # Slack tokens
  "ghp_[a-zA-Z0-9]{36}"          # GitHub personal access tokens
  "gho_[a-zA-Z0-9]{36}"          # GitHub OAuth tokens
  "github_pat_[a-zA-Z0-9_]{82}"  # GitHub App tokens
  "AKIA[0-9A-Z]{16}"             # AWS Access Key ID
  "[a-zA-Z0-9/+]{40}"            # Generic 40-char base64 (often AWS secret)
  "xox[a-zA-Z0-9-]{11,48}"       # Generic Slack/Dropbox tokens
  "AIza[0-9A-Za-z\\-_]{35}"      # Google API keys
  "ya29\\.[0-9A-Za-z\\-_]+"      # Google OAuth tokens
  "1?\\/[a-zA-Z0-9_\\-]{43}"     # Google OAuth2
  "EAA[a-zA-Z0-9]{7,}"           # Facebook access tokens
  "sbp_[a-zA-Z0-9]{64}"          # Stripe/PayPal
  "rk_live_[a-zA-Z0-9]{48}"      # Stripe restricted keys
  "b96dba[a-zA-Z0-9]{20,}"       # GLM API keys (known pattern)
)

FOUND_KEYS=false

for pattern in "${API_KEY_PATTERNS[@]}"; do
  log_verbose "Scanning for pattern: $pattern"

  # Search in common file extensions, exclude node_modules, .git, etc.
  RESULTS=$(grep -r -E --include="*.{js,ts,tsx,jsx,json,env,md,txt,yml,yaml}" \
    --exclude-dir=node_modules \
    --exclude-dir=.git \
    --exclude-dir=dist \
    --exclude-dir=build \
    --exclude-dir=coverage \
    --exclude-dir=.next \
    --exclude-dir=.turbo \
    --exclude="package*.json" \
    -E "$pattern" . 2>/dev/null || true)

  if [ ! -z "$RESULTS" ]; then
    FOUND_KEYS=true
    log_error "Potential API key found (pattern: $pattern)"
    echo "$RESULTS" | head -5
    if [ "$VERBOSE" = false ]; then
      echo "  (use --verbose to see all occurrences)"
    fi
  fi
done

if [ "$FOUND_KEYS" = false ]; then
  log_success "No exposed API keys found"
else
  log_error "API keys detected! Review and remove immediately."
fi

# Check for .env file with real values
if [ -f ".env" ]; then
  log_info "Checking .env file for hardcoded values..."

  # Check if .env contains actual keys (not just placeholders)
  if grep -E "=(your_.*_key|placeholder|changeme|example)" .env > /dev/null 2>&1; then
    log_success ".env contains placeholder values only"
  else
    log_warning ".env contains non-placeholder values. Review for security."
    if [ "$VERBOSE" = true ]; then
      grep -E "=" .env | grep -v "your_\|placeholder\|changeme\|example\|#" | head -10
    fi
  fi
else
  log_info ".env file not found (this is OK if using other secret management)"
fi

# ==========================================
# 2. Check .gitignore completeness
# ==========================================
log_info "Checking .gitignore completeness..."

REQUIRED_IGNORE_PATTERNS=(
  "node_modules/"
  ".env"
  "*.log"
  "dist/"
  "build/"
  ".DS_Store"
  "*.pem"
  "*.key"
)

MISSING_PATTERNS=()

for pattern in "${REQUIRED_IGNORE_PATTERNS[@]}"; do
  if ! grep -q "$pattern" .gitignore 2>/dev/null; then
    MISSING_PATTERNS+=("$pattern")
  fi
done

if [ ${#MISSING_PATTERNS[@]} -eq 0 ]; then
  log_success ".gitignore contains all required patterns"
else
  log_warning ".gitignore is missing ${#MISSING_PATTERNS[@]} recommended patterns:"
  for pattern in "${MISSING_PATTERNS[@]}"; do
    echo "  - $pattern"
  done

  if [ "$AUTO_FIX" = true ]; then
    log_info "Adding missing patterns to .gitignore..."
    for pattern in "${MISSING_PATTERNS[@]}"; do
      echo "$pattern" >> .gitignore
    done
    log_success "Added missing patterns to .gitignore"
  fi
fi

# ==========================================
# 3. Check for sensitive files in repo
# ==========================================
log_info "Checking for sensitive files in repository..."

SENSITIVE_FILES=(
  ".env"
  ".env.local"
  ".env.production"
  "*.pem"
  "*.key"
  "*.p12"
  "*.pfx"
  "id_rsa"
  "id_dsa"
  "id_ecdsa"
  "id_ed25519"
  "*.log"
  "npm-debug.log*"
  "yarn-debug.log*"
  "yarn-error.log*"
)

for file_pattern in "${SENSITIVE_FILES[@]}"; do
  FOUND_FILES=$(find . -type f -name "$file_pattern" 2>/dev/null | grep -v node_modules | grep -v .git || true)

  if [ ! -z "$FOUND_FILES" ]; then
    log_warning "Sensitive file found: $file_pattern"
    if [ "$VERBOSE" = true ]; then
      echo "$FOUND_FILES"
    fi
  fi
done

# Check for files with secrets in commit history (last 5 commits)
log_verbose "Checking recent commits for secrets..."
if command -v git >/dev/null 2>&1; then
  SECRET_COMMIT_PATTERN="(password|secret|api[_-]?key|token|credential|auth)"

  # Check if any of the last 5 commits mention secrets
  if git log --oneline -5 | grep -iE "$SECRET_COMMIT_PATTERN" >/dev/null 2>&1; then
    log_warning "Recent commits mention secret-related keywords"
    if [ "$VERBOSE" = true ]; then
      git log --oneline -5 | grep -iE "$SECRET_COMMIT_PATTERN"
    fi
  else
    log_success "No secret-related commits in recent history"
  fi
fi

# ==========================================
# 4. Check environment variable validation
# ==========================================
log_info "Checking environment variable configuration..."

# Check if env.ts or similar validation file exists
if [ -f "apps/api/src/config/env.ts" ] || [ -f "src/config/env.ts" ]; then
  log_success "Environment validation file found"
else
  log_warning "No environment validation file found (recommended: src/config/env.ts with Zod)"
fi

# Check .env.example exists and is documented
if [ -f ".env.example" ]; then
  # Count documented variables
  DOC_VAR_COUNT=$(grep -c "^[A-Z_].*=" .env.example 2>/dev/null || echo 0)
  ACTUAL_VAR_COUNT=$(grep -c "^[A-Z_].*=" .env 2>/dev/null || echo 0)

  if [ "$DOC_VAR_COUNT" -gt 0 ] && [ "$ACTUAL_VAR_COUNT" -ge "$DOC_VAR_COUNT" ]; then
    log_success ".env.example is documented ($DOC_VAR_COUNT variables)"
  else
    log_warning ".env.example may be incomplete (${DOC_VAR_COUNT} documented vs ${ACTUAL_VAR_COUNT} actual)"
  fi
else
  log_warning ".env.example not found (recommended for documenting environment variables)"
fi

# ==========================================
# 5. Check for dependency vulnerabilities
# ==========================================
log_info "Checking for known vulnerabilities in dependencies..."

if command -v npm >/dev/null 2>&1; then
  log_verbose "Running npm audit..."
  AUDIT_OUTPUT=$(npm audit --audit-level moderate 2>&1 || true)

  if echo "$AUDIT_OUTPUT" | grep -q "found [1-9]"; then
    VULN_COUNT=$(echo "$AUDIT_OUTPUT" | grep "found" | grep -oE '[0-9]+')
    log_warning "Found $VULN_COUNT vulnerabilities in dependencies"

    if [ "$VERBOSE" = true ]; then
      echo "$AUDIT_OUTPUT" | head -20
    fi

    if [ "$AUTO_FIX" = true ]; then
      log_info "Attempting to fix vulnerabilities..."
      npm audit fix
      log_success "Vulnerabilities fixed"
    fi
  else
    log_success "No moderate or high vulnerabilities found"
  fi
elif command -v pnpm >/dev/null 2>&1; then
  log_verbose "Running pnpm audit..."
  AUDIT_OUTPUT=$(pnpm audit 2>&1 || true)

  if echo "$AUDIT_OUTPUT" | grep -qE "(vulnerabilities|high|critical)"; then
    log_warning "Potential vulnerabilities found in pnpm dependencies"
  else
    log_success "No vulnerabilities found in pnpm dependencies"
  fi
else
  log_warning "Neither npm nor pnpm found. Cannot audit dependencies."
fi

# ==========================================
# 6. Check file permissions
# ==========================================
log_info "Checking file permissions..."

# Scripts should not be world-writable
WORLD_WRITABLE=$(find . -type f -name "*.sh" -perm /002 2>/dev/null | grep -v node_modules || true)

if [ ! -z "$WORLD_WRITABLE" ]; then
  log_warning "Found world-writable shell scripts:"
  if [ "$VERBOSE" = true ]; then
    echo "$WORLD_WRITABLE"
  fi
else
  log_success "All shell scripts have secure permissions"
fi

# ==========================================
# 7. Check for hardcoded ports and URLs
# ==========================================
log_info "Checking for hardcoded development values in production code..."

# Check for localhost URLs in certain files
LOCALHOST_PATTERNS=(
  "localhost:[0-9]{4}"
  "127\.0\.0\.1:[0-9]{4}"
  "http://[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+:[0-9]{4}"
)

for pattern in "${LOCALHOST_PATTERNS[@]}"; do
  RESULTS=$(grep -r -E --include="*.{ts,tsx,js,jsx}" \
    --exclude-dir=node_modules \
    --exclude-dir=.git \
    --exclude-dir=tests \
    --exclude-dir=__tests__ \
    -E "$pattern" apps/ 2>/dev/null || true)

  if [ ! -z "$RESULTS" ]; then
    log_verbose "Found potential hardcoded localhost URL:"
    echo "$RESULTS" | head -3
  fi
done

log_success "Hardcoded URL check complete"

# ==========================================
# 8. Check CORS and security middleware
# ==========================================
log_info "Checking security middleware configuration..."

# Check if Helmet is configured
if grep -r "helmet" apps/api/src/*.ts apps/api/src/*/*.ts >/dev/null 2>&1; then
  log_success "Helmet security middleware is configured"
else
  log_warning "Helmet middleware not found. Consider adding security headers."
fi

# Check if rate limiting is configured
if grep -r "rateLimit\|rate-limit" apps/api/src/*.ts apps/api/src/*/*.ts >/dev/null 2>&1; then
  log_success "Rate limiting is configured"
else
  log_warning "Rate limiting not configured. Consider adding rate limiting."
fi

# ==========================================
# 9. Summary
# ==========================================
echo ""
echo "=========================================="
echo "🔒 Security Audit Summary"
echo "=========================================="
echo ""

if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
  log_success "✓ No security issues found!"
  EXIT_CODE=0
elif [ $ERRORS -eq 0 ]; then
  echo -e "${YELLOW}⚠ ${WARNINGS} warning(s) found${NC}"
  echo "Review warnings and consider addressing them."
  EXIT_CODE=0
else
  echo -e "${RED}✗ ${ERRORS} error(s) and ${WARNINGS} warning(s) found${NC}"
  echo "Critical issues must be addressed before deployment."
  EXIT_CODE=1
fi

echo ""
echo "Recommendations:"
echo "  • Run this script as a pre-commit hook"
echo "  • Use --fix flag to auto-fix certain issues"
echo "  • Review all warnings and address security concerns"
echo "  • Keep dependencies updated: npm audit / pnpm audit"
echo ""

if [ "$AUTO_FIX" = true ]; then
  echo -e "${GREEN}✓ Auto-fix applied where possible${NC}"
fi

exit $EXIT_CODE
