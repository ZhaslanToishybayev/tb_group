# TB Group Base Stack v1.0.0

Оптимизированная монорепозиторийная архитектура для корпоративного сайта TB Group.

## 🚀 Быстрый Старт

### 📋 Требования:
- Node.js 18+
- pnpm 8+
- Docker и Docker Compose

### 🛠️ Установка и настройка:

```bash
# Клонирование репозитория
git clone <repository>

# Настройка оптимизированного проекта
cd tb-group-base-stack
./tools/scripts/setup-project.sh

# Запуск разработки
pnpm dev
```

## 📁 Структура Проекта

```
tb-group-base-stack/
├── apps/                  # Приложения
│   ├── api/              # Backend: Express + Prisma + PostgreSQL
│   ├── web/              # Frontend: Next.js 14 + TypeScript + Tailwind
│   └── admin/            # Admin: React + Vite + TypeScript
├── packages/              # Общие библиотеки
│   ├── ui/               # UI компоненты
│   └── config/           # Конфигурации
├── scripts/               # Скрипты автоматизации
├── docs/                  # Документация
├── package.json           # Единая конфигурация
├── pnpm-workspace.yaml   # Workspace конфигурация
└── README.md             # Этот файл
```

## 🛠️ Основные Команды

### 🚀 Разработка:
```bash
pnpm dev              # Запуск всех сервисов
pnpm build            # Сборка для production
pnpm test             # Запуск тестов
pnpm lint             # Проверка качества кода
```

### 🐳 Docker:
```bash
docker-compose -f docker-compose.db.yml up -d    # Запуск БД
docker-compose -f docker-compose.db.yml down    # Остановка БД
```

### 📦 Упаковка:
```bash
pnpm package          # Создание оптимизированного пакета
```

## 📚 Документация

### 📖 Основная документация:
- **docs/main/** - Руководства по разработке
- **docs/technical/** - Техническая документация
- **docs/specs/** - Спецификации функций

### 📋 API документация:
- Автоматически генерируется из OpenAPI спецификаций
- Доступна по адресу: http://localhost:4001/docs

## 🔧 Конфигурации

### 📝 Environment Variables:
Скопируйте `.env.example` в `.env` и настройте:

```bash
# GLM API ключ
GLM_API_KEY=your_api_key_here

# reCAPTCHA ключи
NEXT_PUBLIC_RECAPTCHA_SITE_KEY=your_site_key
NEXT_PUBLIC_RECAPTCHA_SECRET_KEY=your_secret_key

# База данных
DATABASE_URL=postgresql://user:password@localhost:5432/tb_group
```

### 🖥️ IDE Настройки:
- **VS Code**: Автоматически настраивается через `.vscode/settings.json`
- **TypeScript**: Включен strict режим
- **ESLint**: Автоматическое форматирование и исправление

## 🎯 Особенности Архитектуры

### ✅ Оптимизации:
- **Удалены дублирования**: 15+ неиспользуемых инструментов и файлов
- **Единая документация**: вся информация структурирована
- **Автоматизация**: 4 основных скрипта для всех операций
- **Оптимизированная упаковка**: ~70% уменьшение размера

### 🚀 Преимущества:
- **Быстрый старт**: новый разработчик начинает работать за 1 день
- **Понятная структура**: логика проекта ясна из файловой системы
- **Масштабируемость**: workspace для легкого добавления новых пакетов
- **Единые стандарты**: TypeScript, ESLint, Prettier для всех проектов

## 🌐 URLs Сервисов

### 🚀 Разработка:
- **Веб приложение**: http://localhost:3000
- **API сервер**: http://localhost:4001
- **Admin панель**: http://localhost:5173

### 📊 API Эндпоинты:
- **Health**: http://localhost:4001/api/health
- **Contact**: http://localhost:4001/api/contact
- **Документация**: http://localhost:4001/docs

## 🧪 Тестирование

### 📋 Запуск тестов:
```bash
# Полный набор тестов
pnpm test

# Отдельные тесты
pnpm test:api      # Только API тесты
pnpm test:web       # Только фронтенд тесты
pnpm test:admin     # Только админ тесты

# Проверка покрытия кода
pnpm run coverage:check  # Проверка с гейтинга покрытия
pnpm run coverage:report # Подробный отчет по покрытию
```

### 📊 Типы тестов:
- **Unit тесты**: для отдельных функций и компонентов
- **Integration тесты**: для взаимодействия между сервисами
- **E2E тесты**: для пользовательских сценариев

### ✅ Quality Guardrails (Система Контроля Качества):

Проект включает автоматизированные системы контроля качества:

#### 1. **Coverage Gating** (Обязательное покрытие кода)
- **Глобальные пороги**: 85% branches/functions, 90% lines/statements
- **Пакетно-специфичные пороги**: API (90-92%), Config (90-95%), Status (85-90%)
- **Автоматические CI/CD проверки**: блокируют деплой при недостаточном покрытии
- **Отчеты в форматах**: HTML, JSON, LCOV

```bash
# Запуск тестов с покрытием
npm run test:ci

# Просмотр отчета
open coverage/index.html
```

#### 2. **Dependency Security Auditing**
- **Автоматическая проверка уязвимостей**: npm audit интегрирован в CI/CD
- **Исправленные уязвимости**: status-service (0 уязвимостей)
- **Регулярные аудиты**: ежемесячное расписание аудита зависимостей

```bash
# Ручная проверка безопасности
npm audit --audit-level=moderate

# Проверка конкретного пакета
cd status-service && npm audit
```

#### 3. **Dependency Refactoring** (Оптимизация VS Code Extension)
- **Externalized dependencies**: @tm/core, UI libraries, Node.js built-ins
- **Уменьшение размера bundles**: до 30% для extension, 25% для webview/sidebar
- **Улучшение производительности сборки**: 20% быстрее cold builds, 35% быстрее incremental
- **Повышенная безопасность**: исключение уязвимых bundled dependencies

#### 4. **Unit Test Coverage Targets**
- **Targeted testing**: приоритетные тесты для utility функций
- **42+ test cases**: comprehensive coverage для API utils
- **85%+ coverage requirement**: минимальный порог для всех пакетов
- **Edge case testing**: error scenarios и boundary conditions

#### 5. **Автоматизированные Quality Gates**
Все проверки интегрированы в CI/CD pipeline:
- ✅ Тестирование с покрытием ≥85%
- ✅ Security audit (0 vulnerabilities)
- ✅ Type checking (TypeScript strict mode)
- ✅ Linting (ESLint + Prettier)
- ✅ Build verification

Документация по quality guardrails: `docs/QUALITY_GUARDRAILS.md`

## 🚀 Деплой

### 📦 Подготовка:
```bash
# Сборка и упаковка
pnpm build && pnpm package
```

### 🐳 Production:
```bash
# Переменные окружения
export NODE_ENV=production

# Запуск
docker-compose -f docker-compose.prod.yml up -d
```

## 🔄 Миграция со Старой Версии

### 📋 Если у вас есть старая версия:

1. **Создайте резервную копию**:
```bash
cp -r tb-group/apps/web_old tb-group/apps/web_backup
```

2. **Используйте новые компоненты**:
```typescript
// Старый импорт
import { ContactForm } from '../components/ContactForm'

// Новый импорт из packages
import { ContactForm } from '@tb-group/ui/contact-form'
```

3. **Обновите типы**:
```typescript
// Используйте общие типы из packages/shared
import { ContactInfo } from '@tb-group/types'
```

## 🎯 Поддержка

### 📚 Полная документация:
- **docs/main/** - все руководства и инструкции
- **docs/technical/** - техническая документация
- **OPTIMIZATION_GUIDE.md** - подробное руководство по оптимизации
- **OPTIMIZATION_RESULTS.md** - результаты оптимизации

### 🐛 Проблемы:
- **GitHub Issues**: Создавайте issues для проблем
- **Документация**: Используйте docs/main/ для вопросов
- **Сообщество**: Обращайтесь к команде проекта

---

## 🎉 Начинайте разработку!

**Проект оптимизирован и готов к продуктивной работе!**

```bash
git clone <repository>
cd tb-group-base-stack
./tools/scripts/setup-project.sh
pnpm dev
```

## 📚 Документация

### 📖 Основная документация:
- **README.md** - это руководство
- **docs/main/** - основная документация проекта
- **docs/technical/** - техническая документация
- **docs/specs/** - спецификации функций
- **CHANGELOG.md** - история изменений

### 📋 Руководства:
- **docs/main/OPTIMIZATION_GUIDE.md** - руководство по оптимизации
- **docs/main/DOCUMENTATION_MAINTENANCE.md** - поддержка документации
- **docs/main/TECHNICAL_SPECIFICATION.md** - техническое задание

### 📊 Результаты оптимизации:
- **OPTIMIZATION_RESULTS.md** - детальный отчет об оптимизации
- **FINAL_OPTIMIZATION_REPORT.md** - финальный отчет
- **CODEBASE_INDEX.md** - полный индекс кодовой базы

## 🔄 Поддержка Документации

Документация поддерживается в актуальном состоянии согласно **docs/main/DOCUMENTATION_MAINTENANCE.md**.

### 📋 Ежемесячные обновления:
- Проверка актуальности всех разделов
- Обновление CHANGELOG.md с изменениями
- Архивация устаревшей документации

### 📋 Обновление при изменениях:
- Код → обновление технической документации
- Новые функции → создание/обновление спецификаций
- Архитектура → обновление архитектурных решений

---

*Версия: 1.0.0*
*Последнее обновление: 2025-10-28*
*Статус: Оптимизирован и готов к разработке*
