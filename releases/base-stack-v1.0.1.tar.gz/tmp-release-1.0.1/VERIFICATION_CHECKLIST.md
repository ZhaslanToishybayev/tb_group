# Release Verification Checklist

## Pre-Release Validation ✅

### Quality Gates
- [ ] Test coverage ≥85% (run: `npm run coverage:check`)
- [ ] Security audit clean (run: `npm audit --audit-level=moderate`)
- [ ] All tests pass (run: `npm test`)
- [ ] Type checking passes (run: `npm run typecheck`)
- [ ] Linting passes (run: `npm run lint`)
- [ ] Build succeeds (run: `npm run build`)

### Documentation
- [ ] README.md updated
- [ ] DEPLOYMENT.md updated
- [ ] CHANGELOG.md updated
- [ ] QUALITY_GUARDRAILS.md created
- [ ] RELEASE_NOTES.md created

### Files Included
- [ ] apps/ (all applications)
- [ ] packages/ (shared packages)
- [ ] docs/ (documentation)
- [ ] .taskmaster/ (Task Master integration)
- [ ] scripts/ (automation scripts)
- [ ] .github/workflows/ (CI/CD)
- [ ] Configuration files (package.json, pnpm-workspace.yaml, docker-compose.yml)

### Files Excluded
- [ ] node_modules/ (dependencies)
- [ ] .env (environment with secrets)
- [ ] dist/ (build artifacts)
- [ ] coverage/ (test coverage)
- [ ] .cache/ (cache directories)
- [ ] *.log (log files)

## Post-Release Validation

### Installation Test
```bash
# Extract archive
tar -xzf releases/base-stack-v1.0.1.tar.gz
cd base-stack-v1.0.1

# Install dependencies
pnpm install

# Run quality checks
npm run test:ci
npm run coverage:check
npm audit --audit-level=moderate
```

### Build Test
```bash
# Build project
npm run build

# Verify builds succeed
ls -la apps/*/dist/ 2>/dev/null || echo "Build artifacts created"
```

### Documentation Test
```bash
# Check documentation exists
test -f README.md && echo "✅ README.md exists"
test -f DEPLOYMENT.md && echo "✅ DEPLOYMENT.md exists"
test -f CHANGELOG.md && echo "✅ CHANGELOG.md exists"
test -f docs/QUALITY_GUARDRAILS.md && echo "✅ QUALITY_GUARDRAILS.md exists"
test -f RELEASE_NOTES.md && echo "✅ RELEASE_NOTES.md exists"
```

## Release Manager Notes

- **Version**: 1.0.1
- **Release Date**: 2025-10-31
- **Type**: Quality Enhancement
- **Size**: [to be calculated]
- **SHA256**: [to be calculated]
- **Verified by**: [release manager]
- **Date verified**: [verification date]
