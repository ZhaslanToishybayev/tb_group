import type { Metadata } from 'next';
import Link from 'next/link';

import {
  HeroPromo,
  ServicesCarousel,
  AdvantagesSection,
  ClientLogosMarquee,
  TestimonialsTeaser,
  CTASection,
  SectionHeading,
  type Advantage,
  type ClientLogo,
} from '../../components/home';
import {
  getServices,
  getCases,
  getReviews,
  getBanners,
  getSettings,
  type Case,
  type CaseListResult,
} from '../../lib/api';

export const metadata: Metadata = {
  title: 'TB Group — Облачные решения для бизнеса',
  description: 'Внедрение Мой Склад, Битрикс24 и корпоративной телефонии под ключ.',
};

const defaultAdvantages: Advantage[] = [
  {
    title: 'Комплексное внедрение «под ключ»',
    description: 'Проектируем архитектуру, настраиваем интеграции и обучаем сотрудников, чтобы команда сразу работала в новой системе.',
  },
  {
    title: 'Гарантируем быстрый эффект',
    description: 'Показываем измеримый рост эффективности уже в первые недели — фиксируем KPI и сопровождаем по SLA.',
  },
  {
    title: 'Прозрачная коммуникация',
    description: 'Закрепляем проектного менеджера, ведём единый контур в Bitrix24 и предоставляем понятный план миров.',
  },
];

const defaultClientLogos: ClientLogo[] = [
  { name: 'SaaS Group', logoUrl: '' },
  { name: 'Logist Pro', logoUrl: '' },
  { name: 'Retail Hub', logoUrl: '' },
  { name: 'FinTech One', logoUrl: '' },
];

const parseSettingArray = <T,>(value: unknown, fallback: T[]): T[] => {
  if (!value) {
    return fallback;
  }
  if (Array.isArray(value)) {
    return value as T[];
  }
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value) as T[];
      return Array.isArray(parsed) ? parsed : fallback;
    } catch {
      return fallback;
    }
  }
  return fallback;
};

export default async function HomePage() {
  const [services, casesResult, reviews, banners, settings] = await Promise.all([
    getServices().catch(() => []),
    getCases({}).catch<CaseListResult>(() => ({ items: [], nextCursor: null })),
    getReviews({ isFeatured: true }).catch(() => []),
    getBanners().catch(() => []),
    getSettings().catch(() => []),
  ]);

  const heroBanner = banners.find((banner) => banner.placement === 'HOME_HERO');
  const advantagesSetting = settings.find((setting) => setting.key === 'HOMEPAGE_ADVANTAGES')?.value;
  const logosSetting = settings.find((setting) => setting.key === 'HOMEPAGE_CLIENT_LOGOS')?.value;

  const advantages = parseSettingArray<Advantage>(advantagesSetting, defaultAdvantages);
  const logos = parseSettingArray<ClientLogo>(logosSetting, defaultClientLogos);
  const highlightedCases = casesResult.items.slice(0, 3);

  return (
    <div>
      <HeroPromo banner={heroBanner} />
      <ServicesCarousel services={services} />
      <AdvantagesSection advantages={advantages} />
      <ClientLogosMarquee logos={logos} />
      <CaseHighlights cases={highlightedCases} />
      <TestimonialsTeaser reviews={reviews} />
      <CTASection />
    </div>
  );
}

function CaseHighlights({ cases }: { cases: Case[] }) {
  if (cases.length === 0) {
    return null;
  }

  return (
    <section className="section bg-slate-900/30" id="cases">
      <div className="mx-auto max-w-6xl px-4">
        <SectionHeading title="Кейсы" subtitle="Узнайте, как мы запускаем облачные экосистемы для разных отраслей." align="left" />
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {cases.map((item) => (
            <article key={item.id} className="rounded-3xl border border-white/10 bg-slate-900/60 p-6 shadow-xl">
              <p className="text-xs uppercase tracking-wide text-blue-300/80">{item.category}</p>
              <h3 className="mt-3 text-xl font-semibold text-white">{item.projectTitle}</h3>
              <p className="mt-2 line-clamp-4 text-sm text-slate-300">{item.summary}</p>
              <Link
                href={`/cases/${item.slug}`}
                className="mt-6 inline-flex items-center text-sm font-semibold text-blue-400 transition hover:text-blue-300"
              >
                Читать подробнее →
              </Link>
            </article>
          ))}
        </div>
        <div className="mt-8 text-right">
          <Link href="/cases" className="text-sm font-semibold text-blue-400 transition hover:text-blue-300">
            Все кейсы →
          </Link>
        </div>
      </div>
    </section>
  );
}
