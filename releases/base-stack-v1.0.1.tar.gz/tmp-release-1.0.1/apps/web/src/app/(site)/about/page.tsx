'use client';

import React from 'react';
import { motion } from 'framer-motion';

export const metadata = {
  title: 'О компании — TB Group',
};

interface TimelineItem {
  year: string;
  title: string;
  description: string;
}

interface TeamMember {
  name: string;
  position: string;
  photo?: string;
}

interface Office {
  city: string;
  address: string;
  photo?: string;
}

interface Partner {
  name: string;
  logo?: string;
}

// Временные данные до подключения API
const timelineData: TimelineItem[] = [
  { year: '2018', title: 'Основание компании', description: 'Начало деятельности в области автоматизации складских операций' },
  { year: '2020', title: 'Расширение услуг', description: 'Запуск интеграционных проектов с Мой Склад и Битрикс24' },
  { year: '2022', title: 'Развитие экспертизы', description: 'Создание собственной команды разработчиков' },
  { year: '2024', title: 'Новые горизонты', description: 'Выход на рынок корпоративных решений' },
];

const teamData: TeamMember[] = [
  { name: 'Александр Петров', position: 'CEO', photo: '/images/team/ceo.jpg' },
  { name: 'Мария Иванова', position: 'CTO', photo: '/images/team/cto.jpg' },
  { name: 'Дмитрий Сидоров', position: 'Lead Developer', photo: '/images/team/lead-dev.jpg' },
  { name: 'Елена Козлова', position: 'Project Manager', photo: '/images/team/pm.jpg' },
];

const partnersData: Partner[] = [
  { name: 'Мой Склад', logo: '/images/partners/moysklad.png' },
  { name: 'Битрикс24', logo: '/images/partners/bitrix24.png' },
  { name: '1С', logo: '/images/partners/1c.png' },
];

const officesData: Office[] = [
  { city: 'Алматы', address: 'ул. Абая, 120', photo: '/images/offices/almaty.jpg' },
  { city: 'Астана', address: 'ул. Байтырсынова, 45', photo: '/images/offices/astana.jpg' },
  { city: 'Шымкент', address: 'ул. Достык, 88', photo: '/images/offices/shymkent.jpg' },
];

export default function AboutPage() {
  // TODO: Заменить на реальные данные из API
  const aboutData = {
    story: 'TB Group — команда экспертов по цифровой трансформации бизнеса. Мы помогаем компаниям автоматизировать процессы, управлять данными и повышать эффективность через современные облачные решения.',
    team: teamData,
    certifications: ['ISO 9001:2015', 'Microsoft Gold Partner', 'Битрикс24 Certified'],
    partnerships: partnersData,
    timeline: timelineData,
    offices: officesData
  };

  return (
    <div className="section">
      <div className="mx-auto max-w-6xl px-4">
        <motion.h1
          className="text-4xl font-semibold text-white mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          О компании
        </motion.h1>
        
        {/* История компании */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-semibold text-white mb-8">Наша история</h2>
          <div className="relative">
            <div className="absolute left-0 top-0 w-1 h-full bg-gradient-to-r from-blue-600 to-transparent"></div>
            <div className="relative bg-slate-900/60 rounded-2xl p-8 ml-8">
              <div className="space-y-8">
                {aboutData.timeline.map((item, index) => (
                  <motion.div
                    key={index}
                    className="flex gap-6"
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <div className="flex-shrink-0 w-16 text-3xl font-bold text-blue-400">
                      {item.year}
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-2">{item.title}</h3>
                      <p className="text-slate-300">{item.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </motion.section>

        {/* Наша команда */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-semibold text-white mb-8">Наша команда</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
            {aboutData.team.map((member, index) => (
              <motion.div
                key={index}
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
              >
                {member.photo ? (
                  <img
                    src={member.photo}
                    alt={member.name}
                    className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
                  />
                ) : (
                  <div className="w-24 h-24 rounded-full mx-auto mb-4 bg-slate-700 flex items-center justify-center">
                    <span className="text-2xl text-white font-semibold">
                      {member.name.charAt(0)}
                    </span>
                  </div>
                )}
                <h3 className="font-semibold text-white">{member.name}</h3>
                <p className="text-slate-300">{member.position}</p>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Сертификаты */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-semibold text-white mb-8">Сертификаты и награды</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {aboutData.certifications.map((cert, index) => (
              <motion.div
                key={index}
                className="bg-slate-800/50 rounded-lg p-6 text-center hover:bg-slate-800/70 transition-colors"
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <div className="text-2xl font-bold text-white mb-2">{cert}</div>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Партнеры */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-semibold text-white mb-8">Наши партнеры</h2>
          <div className="flex flex-wrap justify-center gap-8">
            {aboutData.partnerships.map((partner, index) => (
              <motion.div
                key={index}
                className="bg-slate-800/50 rounded-lg p-6 flex items-center gap-4 hover:bg-slate-800/70 transition-colors"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ scale: 1.05 }}
              >
                {partner.logo && (
                  <img
                    src={partner.logo}
                    alt={partner.name}
                    className="h-12 w-auto max-w-[120px]"
                  />
                )}
                <p className="text-white font-medium">{partner.name}</p>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Офисы */}
        <motion.section
          className="mb-16"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-semibold text-white mb-8">Наши офисы</h2>
          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            {aboutData.offices.map((office, index) => (
              <motion.div
                key={index}
                className="bg-slate-800/50 rounded-lg p-6 text-center hover:bg-slate-800/70 transition-colors"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                {office.photo ? (
                  <img
                    src={office.photo}
                    alt={`Офис в ${office.city}`}
                    className="w-full h-32 object-cover rounded-lg mb-4"
                  />
                ) : (
                  <div className="w-full h-32 bg-slate-700 rounded-lg mb-4 flex items-center justify-center">
                    <span className="text-2xl text-white">{office.city.charAt(0)}</span>
                  </div>
                )}
                <h3 className="text-xl font-semibold text-white mb-2">{office.city}</h3>
                <p className="text-slate-300">{office.address}</p>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Призыв к действию */}
        <motion.section
          className="text-center"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-semibold text-white mb-8">Готовы помочь вашему бизнесу</h2>
          <p className="text-xl text-slate-300 mb-8">
            Свяжитесь с нами для консультации и обсуждения вашего проекта
          </p>
          <motion.button
            className="px-8 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => window.location.href = '/contact'}
          >
            Связаться с нами
          </motion.button>
        </motion.section>
      </div>
    </div>
  );
}
