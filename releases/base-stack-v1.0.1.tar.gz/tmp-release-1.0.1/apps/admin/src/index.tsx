export function AdminApp() {
  return <main>TB Group admin panel placeholder</main>;
}

export default AdminApp;
