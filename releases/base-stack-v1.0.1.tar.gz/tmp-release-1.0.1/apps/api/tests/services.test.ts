import { describe, it } from 'vitest';

describe.skip('services API', () => {
  it('creates and fetches services', async () => {
    // TODO: implement integration test when test harness is wired.
  });
});
