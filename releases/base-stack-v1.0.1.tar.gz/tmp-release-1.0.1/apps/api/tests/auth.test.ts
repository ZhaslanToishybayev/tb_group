import { describe, it } from 'vitest';

describe.skip('auth flow', () => {
  it('logs in admin and issues tokens', async () => {
    // TODO: Implement integration test when test database harness is ready.
  });
});
