module.exports = {
  extends: [require.resolve('../../../eslint.config.js')],
};
